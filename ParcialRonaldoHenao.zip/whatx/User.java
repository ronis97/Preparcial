public class User {
    private String nickName;
    private String phone;
    private String about;
    public String getPhone(){
        return phone;
    }

}
