import java.time.LocalDateTime;
public class Message {
	private int id;
	private String text;
	private LocalDateTime date;
	private boolean read;
	private User sender;
	private File file;
}
